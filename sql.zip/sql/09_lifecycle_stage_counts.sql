
SELECT event_stage, COUNT(*) AS events
FROM tickets_sample
GROUP BY event_stage
ORDER BY events DESC;
