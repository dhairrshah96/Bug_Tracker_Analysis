
SELECT resolver, COUNT(*) AS tickets
FROM tickets_sample
WHERE resolver IS NOT NULL
GROUP BY resolver
ORDER BY tickets DESC
LIMIT 10;
