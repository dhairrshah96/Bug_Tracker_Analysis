
SELECT weekday, COUNT(*) AS tickets
FROM tickets_sample
GROUP BY weekday
ORDER BY
  CASE weekday
    WHEN 'Monday' THEN 1 WHEN 'Tuesday' THEN 2 WHEN 'Wednesday' THEN 3
    WHEN 'Thursday' THEN 4 WHEN 'Friday' THEN 5 WHEN 'Saturday' THEN 6
    WHEN 'Sunday' THEN 7 ELSE 8
  END;
