
SELECT priority, ROUND(AVG(customer_satisfaction),2) AS avg_cs, COUNT(*) AS n
FROM tickets_sample
WHERE customer_satisfaction IS NOT NULL
GROUP BY priority
ORDER BY avg_cs DESC;
