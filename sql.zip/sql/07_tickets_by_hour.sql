
SELECT hour, COUNT(*) AS tickets
FROM tickets_sample
GROUP BY hour
ORDER BY hour;
