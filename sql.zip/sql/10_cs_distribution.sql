
SELECT customer_satisfaction AS score, COUNT(*) AS n
FROM tickets_sample
WHERE customer_satisfaction IS NOT NULL
GROUP BY customer_satisfaction
ORDER BY score;
