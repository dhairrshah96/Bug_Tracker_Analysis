
SELECT date, COUNT(*) AS tickets
FROM tickets_sample
GROUP BY date
ORDER BY date;
