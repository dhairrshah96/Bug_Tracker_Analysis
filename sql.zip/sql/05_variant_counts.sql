
SELECT variant, COUNT(*) AS tickets
FROM tickets_sample
GROUP BY variant
ORDER BY tickets DESC
LIMIT 10;
