
SELECT report_channel, COUNT(*) AS tickets
FROM tickets_sample
GROUP BY report_channel
ORDER BY tickets DESC;
