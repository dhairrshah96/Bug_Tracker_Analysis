
SELECT issue_type, COUNT(*) AS tickets
FROM tickets_sample
GROUP BY issue_type
ORDER BY tickets DESC;
