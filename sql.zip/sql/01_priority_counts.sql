
SELECT priority, COUNT(*) AS tickets
FROM tickets_sample
GROUP BY priority
ORDER BY tickets DESC;
