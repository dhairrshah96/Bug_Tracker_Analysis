
SELECT report_channel, ROUND(AVG(customer_satisfaction),2) AS avg_cs, COUNT(*) AS n
FROM tickets_sample
WHERE customer_satisfaction IS NOT NULL
GROUP BY report_channel
ORDER BY avg_cs DESC;
